﻿using BooksConsole.Data;
using BooksConsole.Models;
using BooksConsole.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Data.Sqlite;

// === RUTAS (siempre en la raíz del Project) ===
var projectRoot = Path.GetFullPath(Path.Combine(AppContext.BaseDirectory, "..", "..", ".."));
var dataDir = Path.Combine(projectRoot, "data");
Directory.CreateDirectory(dataDir);

var csvPath = Path.Combine(dataDir, "books.csv");

// === DbContext y migraciones ===
using var db = new AppDbContext();
await db.Database.MigrateAsync();   // crea/actualiza esquema antes de consultar

// (Opcional) Mostrar versión de SQLite contra la MISMA BD que usa el DbContext
var dbPath = Path.Combine(dataDir, "books.db");
using (var raw = new SqliteConnection($"Data Source={dbPath}"))
{
    await raw.OpenAsync();
    var cmd = new SqliteCommand("select sqlite_version()", raw);
    var v = (string)(await cmd.ExecuteScalarAsync())!;
    Console.WriteLine($"[INFO] SQLite v{v}");  // debería imprimir 3.x.y
}

// === Detectar si la BD está vacía ===
bool isEmpty =
    !(await db.Authors.AnyAsync()) &&
    !(await db.Titles.AnyAsync()) &&
    !(await db.Tags.AnyAsync()) &&
    !(await db.TitlesTags.AnyAsync());

if (isEmpty)
{
    Console.WriteLine("La base de datos está vacía, por lo que será llenada a partir de los datos del archivo CSV.");
    Console.WriteLine();
    Console.WriteLine("Procesando...");

    if (!File.Exists(csvPath))
        throw new FileNotFoundException($"CSV no encontrado en {csvPath}");

    var authorByName = new Dictionary<string, Author>(StringComparer.OrdinalIgnoreCase);
    var tagByName    = new Dictionary<string, Tag>(StringComparer.OrdinalIgnoreCase);

    foreach (var (authorName, titleName, tags) in CsvLoader.ReadBooksCsv(csvPath))
    {
        if (!authorByName.TryGetValue(authorName, out var author))
        {
            author = new Author { AuthorName = authorName };
            authorByName[authorName] = author;
            db.Authors.Add(author);
        }

        var title = new Title
        {
            Author = author,
            TitleName = titleName
        };
        db.Titles.Add(title);

        foreach (var tagName in tags)
        {
            if (!tagByName.TryGetValue(tagName, out var tag))
            {
                tag = new Tag { TagName = tagName };
                tagByName[tagName] = tag;
                db.Tags.Add(tag);
            }

            db.TitlesTags.Add(new TitleTag
            {
                Title = title,
                Tag = tag
            });
        }
    }

    await db.SaveChangesAsync();

    Console.WriteLine("Listo.");
}
else
{
    Console.WriteLine("La base de datos se está leyendo para crear los archivos TSV.");
    Console.WriteLine();
    Console.WriteLine("Procesando...");

    var query =
        from t in db.Titles
            .Include(x => x.Author)
            .Include(x => x.TitleTags).ThenInclude(tt => tt.Tag)
        from tt in t.TitleTags.DefaultIfEmpty()
        select new
        {
            AuthorName = t.Author.AuthorName,
            TitleName  = t.TitleName,
            TagName    = tt != null ? tt.Tag.TagName : string.Empty
        };

    var rows = await query.AsNoTracking().ToListAsync();

    var projected = rows.Select(r => (r.AuthorName, r.TitleName, r.TagName));
    var ordered = TsvWriter.OrderForOutput(projected);

    TsvWriter.WritePerInitial(ordered, dataDir);

    Console.WriteLine("Listo.");
}
