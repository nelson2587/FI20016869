namespace BooksConsole.Data;

public record CsvRow(string Author, string Title, string[] Tags);
